function A = Non_symmetricLanczos(A, V, W, m)
  % A matrice n x n
  % V, W matrici n x p
  % m numar intreg
  
  %fac descompunerea QR a lui W^t*V
  endfunction